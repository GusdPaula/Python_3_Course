from eletronic import Smarthphone

galaxy = Smarthphone('Galaxy')
iphone = Smarthphone('Iphone')

galaxy.turn_on()
iphone.turn_of()